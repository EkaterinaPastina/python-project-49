### Hexlet tests and linter status:
[![Actions Status](https://github.com/EkaterinaPastina/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EkaterinaPastina/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/15e67c87b6bdb69fcf30/maintainability)](https://codeclimate.com/github/EkaterinaPastina/python-project-49/maintainability)
